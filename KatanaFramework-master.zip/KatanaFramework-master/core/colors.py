#!/usr/bin/env python
#HEADER#######################
# Katana framework           #
# Colors File                #
# Last Modified: 25/03/2016  #
# Review: 0                  #
#######################HEADER#

W  = '\033[0m'  
R  = '\033[31m' 
G  = '\033[32m' 
O  = '\033[33m' 
B  = '\033[34m' 
P  = '\033[35m' 
C  = '\033[36m' 
GR = '\033[40m'
GY = '\033[43m'
GE = '\033[41m'
GW = '\033[4m'
HH = '\033[1m'