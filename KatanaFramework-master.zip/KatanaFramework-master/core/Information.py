#!/usr/bin/env python2
#HEAD#########################################################
#
# Katana Framework | Information File                        
# Last Modified: 14/03/2017
#
#########################################################HEAD#

__nickname__   = 'Katana Framework'
__author__     = 'RedToor'
__emailadd__   = 'redtoor@inbox.ru'
__twitter__    = 'https://twitter.com/redtoor'
__facebook__   = 'https://facebook.com/redtoor'
__license__    = 'GPLv3'

version        = "1.0.0.1"
date           = "25/12/16:14/03/17"
build          = "0069"
Type           = "FREE"
